RestedXP Guides fix for the WoW Forever beta
=============================================
Problem: the Forever beta client saves add-on settings but never loads them back, so RestedXP
forgets your guide and step every time you reload or restart. This is a Blizzard bug.

Install (game closed):
1. Install RestedXP Guides v4.11.9 normally if you have not.
2. Copy the RXPGuides folder from this pack over the one in
   ...\World of Warcraft\_classic_beta_\Interface\AddOns\   (say yes to replace files).
3. Double-click forever-sv-link.bat. It should end with "Link works" or "Link made".
4. Start the game, pick your guide once, play a minute, then /reload. From then on the guide,
   step and settings survive reloads and restarts.

If you update RestedXP later, redo step 2 (the update removes the fix; the link stays).
Also in this pack: RXPTagMacros, a separate add-on. Copy its folder into AddOns too. It keeps two
macros current with your guide step: RXPTag (targets a quest mob and casts your class's instant tag
spell) and RXPMelee (targets a quest mob and auto-attacks). Drag them from your general macros to
a bar. Type /rxptag for options. It survives RestedXP updates.
