# RestedXP Guides

## [v4.11.5](https://github.com/RestedXP/RXPGuides/tree/v4.11.5) (2026-09-20)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.11.4...v4.11.5) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Fix PrettyDebug call  
- Fix GetItemStats compatibility  
- skyborne druid update  
- Skyborne fix subzoneskips  
- Skyborne Added Vehicle optimization  
- Skyborne: Valanaar Routing 1 + Hunter Taming Quest  
- Enabled built in quest helper on first login  
- Skyborne Routing updates  
- Skyborne bear form quest  
- Ace update  
- Fixed beta specific issues  
- Added 1-6 Human Hunter Forever  
- Skyborne: Second+Third Village Update  
- Shoni the Shilent coord update  
- Skyborne: loop & alliance routing  
- Skyborne: Fix 101 Quest  
- Skyborne: Profession Step improvements  
- Skyborne: Clean up guide creator for the most part  
- Skyborne: Add more training/buy steps and improve waypoints  
- Added new Westfall quests Forever  
- Added Kobold chain quest from Northshire through Elwynn Forever  
- Additional Trainer step  
