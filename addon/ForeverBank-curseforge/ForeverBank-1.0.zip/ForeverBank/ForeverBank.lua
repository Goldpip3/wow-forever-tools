-- Forever Bank
-- Remembers what is in your bank each time you open it, and shows that
-- snapshot anywhere in a Bagnon-style window. Display only: it never moves,
-- uses, buys or sells anything.

local ADDON = ...
local VERSION = '1.0'

local SIZE, SPACING, PAD = 37, 2, 10
local TOP, BOTTOM = 34, 28

local defaults = {
  columns = 10,
  scale = 1,
  alpha = 0.5,
  showMinimap = true,
  minimapAngle = 200,
  chars = {},
}

local db, snap, charKey
local bankOpen = false
local frame, minimapButton
local buttons = {}
local searchText = ''
local scanQueued = false
local lastScanInfo = 'never scanned this session'

local function say(msg)
  DEFAULT_CHAT_FRAME:AddMessage('|cffffd200Forever Bank:|r ' .. tostring(msg))
end

---------------------------------------------------------------------------
-- Container API (new C_Container table, old globals as fallback)
---------------------------------------------------------------------------

local function numSlots(bag)
  local fn = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
  if not fn then return 0 end
  local ok, n = pcall(fn, bag)
  if ok and type(n) == 'number' then return n end
  return 0
end

local function slotInfo(bag, slot)
  if C_Container and C_Container.GetContainerItemInfo then
    local ok, info = pcall(C_Container.GetContainerItemInfo, bag, slot)
    if ok and type(info) == 'table' then
      return info.iconFileID, info.stackCount, info.quality, info.hyperlink, info.itemID
    end
    return nil
  end
  if GetContainerItemInfo then
    local ok, icon, count, _, quality, _, _, link, _, _, itemID = pcall(GetContainerItemInfo, bag, slot)
    if ok then return icon, count, quality, link, itemID end
  end
  return nil
end

-- Every container id that belongs to the character's bank on this client.
-- Classic has the main bank (-1) plus bank bag slots; the Midnight engine
-- uses character bank tabs. Ask the client which it has.
local function bankBags()
  local list, seen = {}, {}
  local function add(id)
    if type(id) == 'number' and not seen[id] then
      seen[id] = true
      list[#list + 1] = id
    end
  end
  local E = Enum and Enum.BagIndex
  if E then
    add(E.Bank)
    for i = 1, 7 do add(E['BankBag_' .. i]) end
    for i = 1, 6 do add(E['CharacterBankTab_' .. i]) end
  end
  if #list == 0 then
    add(BANK_CONTAINER or -1)
    local first = (NUM_BAG_SLOTS or 4) + 1
    for i = first, first + (NUM_BANKBAGSLOTS or 6) - 1 do add(i) end
  end
  return list
end

---------------------------------------------------------------------------
-- Scanning (only while the bank is open)
---------------------------------------------------------------------------

local refresh -- forward

local function scan()
  scanQueued = false
  if not bankOpen or not db then return end
  local bags, total, filled = {}, 0, 0
  for _, bag in ipairs(bankBags()) do
    local n = numSlots(bag)
    if n > 0 then
      local slots = {}
      for slot = 1, n do
        local icon, count, quality, link, itemID = slotInfo(bag, slot)
        if icon or link then
          slots[slot] = { icon = icon, count = count or 1, quality = quality, link = link, id = itemID }
          filled = filled + 1
        else
          slots[slot] = false
        end
      end
      bags[#bags + 1] = { id = bag, size = n, slots = slots }
      total = total + n
    end
  end
  lastScanInfo = ('%d slots, %d items, %d containers'):format(total, filled, #bags)
  if total == 0 then return end -- bank data not ready; keep the old snapshot
  snap = { time = time(), bags = bags, total = total, filled = filled }
  db.chars[charKey] = snap
  if type(ForeverBankCharDB) == 'table' then ForeverBankCharDB.snap = snap end
  if frame and frame:IsShown() then refresh() end
end

local function queueScan()
  if scanQueued or not bankOpen then return end
  scanQueued = true
  if C_Timer and C_Timer.After then
    C_Timer.After(0.15, scan)
  else
    scan()
  end
end

---------------------------------------------------------------------------
-- Item buttons
---------------------------------------------------------------------------

local function itemName(link)
  if type(link) ~= 'string' then return '' end
  return (link:match('%[(.-)%]') or ''):lower()
end

local function buttonEnter(self)
  local item = self.item
  if not item or not item.link then return end
  GameTooltip:SetOwner(self, 'ANCHOR_RIGHT')
  local ok = pcall(GameTooltip.SetHyperlink, GameTooltip, item.link)
  if ok then GameTooltip:Show() else GameTooltip:Hide() end
end

local function buttonLeave()
  GameTooltip:Hide()
end

local function buttonClick(self)
  local item = self.item
  if item and item.link and IsModifiedClick and HandleModifiedItemClick then
    pcall(HandleModifiedItemClick, item.link)
  end
end

local function makeButton(parent)
  local b = CreateFrame('Button', nil, parent)
  b:SetSize(SIZE, SIZE)

  b.bg = b:CreateTexture(nil, 'BACKGROUND')
  b.bg:SetAllPoints()
  b.bg:SetTexture('Interface\\PaperDoll\\UI-Backpack-EmptySlot')

  b.icon = b:CreateTexture(nil, 'BORDER')
  b.icon:SetAllPoints()

  b.slotFrame = b:CreateTexture(nil, 'ARTWORK')
  b.slotFrame:SetTexture('Interface\\Buttons\\UI-Quickslot2')
  b.slotFrame:SetSize(64, 64)
  b.slotFrame:SetPoint('CENTER', 0, -1)

  b.glow = b:CreateTexture(nil, 'OVERLAY')
  b.glow:SetTexture('Interface\\Buttons\\UI-ActionButton-Border')
  b.glow:SetBlendMode('ADD')
  b.glow:SetSize(67, 67)
  b.glow:SetPoint('CENTER')
  b.glow:Hide()

  b.count = b:CreateFontString(nil, 'OVERLAY', 'NumberFontNormal')
  b.count:SetPoint('BOTTOMRIGHT', -5, 2)
  b.count:SetJustifyH('RIGHT')

  b:SetHighlightTexture('Interface\\Buttons\\ButtonHilight-Square', 'ADD')
  b:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
  b:SetScript('OnEnter', buttonEnter)
  b:SetScript('OnLeave', buttonLeave)
  b:SetScript('OnClick', buttonClick)
  return b
end

local function paintButton(b, item)
  b.item = item or nil
  if item then
    b.icon:SetTexture(item.icon or 'Interface\\Icons\\INV_Misc_QuestionMark')
    b.icon:Show()
    if (item.count or 1) > 1 then
      b.count:SetText(item.count)
    else
      b.count:SetText('')
    end
    local q = item.quality
    if type(q) == 'number' and q > 1 and GetItemQualityColor then
      local r, g, bl = GetItemQualityColor(q)
      b.glow:SetVertexColor(r, g, bl, 0.5)
      b.glow:Show()
    else
      b.glow:Hide()
    end
    local match = searchText == '' or itemName(item.link):find(searchText, 1, true)
    b:SetAlpha(match and 1 or 0.3)
  else
    b.icon:Hide()
    b.count:SetText('')
    b.glow:Hide()
    b:SetAlpha(searchText == '' and 1 or 0.3)
  end
end

---------------------------------------------------------------------------
-- Window
---------------------------------------------------------------------------

local function ago(t)
  local s = time() - (t or 0)
  if s < 90 then return 'just now' end
  if s < 3600 then return ('%d min ago'):format(s / 60) end
  if s < 86400 then return ('%d hr ago'):format(s / 3600) end
  return ('%d days ago'):format(s / 86400)
end

refresh = function()
  if not frame then return end
  local cols = math.max(4, math.min(24, db.columns or 10))
  local n = 0
  if snap and snap.bags then
    for _, bag in ipairs(snap.bags) do
      for slot = 1, bag.size or 0 do
        n = n + 1
        local b = buttons[n]
        if not b then
          b = makeButton(frame)
          buttons[n] = b
        end
        local col = (n - 1) % cols
        local row = math.floor((n - 1) / cols)
        b:ClearAllPoints()
        b:SetPoint('TOPLEFT', frame, 'TOPLEFT', PAD + col * (SIZE + SPACING), -(TOP + row * (SIZE + SPACING)))
        paintButton(b, bag.slots and bag.slots[slot] or nil)
        b:Show()
      end
    end
  end
  for i = n + 1, #buttons do buttons[i]:Hide() end

  local rows = math.max(1, math.ceil(n / cols))
  local width = PAD * 2 + cols * (SIZE + SPACING) - SPACING
  local height = TOP + rows * (SIZE + SPACING) - SPACING + BOTTOM
  frame:SetSize(width, n > 0 and height or TOP + 60 + BOTTOM)

  if n == 0 then
    frame.empty:Show()
    frame.status:SetText('')
  else
    frame.empty:Hide()
    local free = (snap.total or n) - (snap.filled or 0)
    if bankOpen then
      frame.status:SetText(('%d/%d free  |cff40ff40live|r'):format(free, snap.total or n))
    else
      frame.status:SetText(('%d/%d free  |cff999999seen %s|r'):format(free, snap.total or n, ago(snap.time)))
    end
  end
  if GetMoney and GetCoinTextureString then
    frame.money:SetText(GetCoinTextureString(GetMoney()))
  end
end

local function savePosition()
  if not frame or not db then return end
  local left, top = frame:GetLeft(), frame:GetTop()
  if left and top then
    db.left, db.top = left, top
    if type(ForeverBankCharDB) == 'table' then
      ForeverBankCharDB.left, ForeverBankCharDB.top = left, top
    end
  end
end

local function buildFrame()
  if frame then return end
  frame = CreateFrame('Frame', 'ForeverBankFrame', UIParent, BackdropTemplateMixin and 'BackdropTemplate' or nil)
  frame:SetFrameStrata('MEDIUM')
  frame:SetToplevel(true)
  frame:SetClampedToScreen(true)
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:SetScale(db.scale or 1)
  if frame.SetBackdrop then
    frame:SetBackdrop({
      bgFile = 'Interface\\ChatFrame\\ChatFrameBackground',
      edgeFile = 'Interface\\Tooltips\\UI-Tooltip-Border',
      edgeSize = 16, tile = true, tileSize = 16,
      insets = { left = 4, right = 4, top = 4, bottom = 4 },
    })
    frame:SetBackdropColor(0, 0, 0, db.alpha or 0.5)
    frame:SetBackdropBorderColor(1, 1, 1, 1)
  end

  local left, top = db.left, db.top
  if not left and type(ForeverBankCharDB) == 'table' then
    left, top = ForeverBankCharDB.left, ForeverBankCharDB.top
  end
  if left and top then
    frame:SetPoint('TOPLEFT', UIParent, 'BOTTOMLEFT', left, top)
  else
    frame:SetPoint('CENTER', -250, 50)
  end

  frame:SetScript('OnMouseDown', function(self, button)
    if button == 'LeftButton' then self:StartMoving() end
  end)
  frame:SetScript('OnMouseUp', function(self)
    self:StopMovingOrSizing()
    savePosition()
  end)
  frame:SetScript('OnHide', function(self)
    self:StopMovingOrSizing()
    savePosition()
  end)
  frame:SetScript('OnShow', function() refresh() end)

  -- bag icon, top left, like Bagnon's owner button
  local icon = frame:CreateTexture(nil, 'ARTWORK')
  icon:SetSize(20, 20)
  icon:SetPoint('TOPLEFT', PAD, -8)
  icon:SetTexture('Interface\\Icons\\INV_Misc_Bag_07')
  icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

  frame.title = frame:CreateFontString(nil, 'ARTWORK', 'GameFontNormalLeft')
  frame.title:SetPoint('LEFT', icon, 'RIGHT', 6, 0)
  frame.title:SetText((UnitName('player') or 'Your') .. "'s Bank")

  local close = CreateFrame('Button', nil, frame, 'UIPanelCloseButton')
  close:SetPoint('TOPRIGHT', -2, -2)

  -- search box
  local ok, search = pcall(CreateFrame, 'EditBox', 'ForeverBankSearch', frame, 'InputBoxTemplate')
  if ok and search then
    search:SetSize(110, 18)
    search:SetPoint('RIGHT', close, 'LEFT', -4, 0)
    search:SetAutoFocus(false)
    search:SetFontObject('ChatFontSmall')
    local hint = search:CreateFontString(nil, 'ARTWORK', 'GameFontDisableSmall')
    hint:SetPoint('LEFT', 2, 0)
    hint:SetText('Search')
    search:SetScript('OnTextChanged', function(self)
      searchText = (self:GetText() or ''):lower()
      hint:SetShown(searchText == '' and not self:HasFocus())
      refresh()
    end)
    search:SetScript('OnEditFocusGained', function() hint:Hide() end)
    search:SetScript('OnEditFocusLost', function(self) hint:SetShown((self:GetText() or '') == '') end)
    search:SetScript('OnEscapePressed', function(self) self:SetText('') self:ClearFocus() end)
    search:SetScript('OnEnterPressed', function(self) self:ClearFocus() end)
    frame.search = search
  end

  frame.status = frame:CreateFontString(nil, 'ARTWORK', 'GameFontHighlightSmall')
  frame.status:SetPoint('BOTTOMLEFT', PAD, 10)

  frame.money = frame:CreateFontString(nil, 'ARTWORK', 'GameFontHighlightSmall')
  frame.money:SetPoint('BOTTOMRIGHT', -PAD, 10)

  frame.empty = frame:CreateFontString(nil, 'ARTWORK', 'GameFontDisable')
  frame.empty:SetPoint('CENTER', 0, 0)
  frame.empty:SetWidth(PAD * 2 + 10 * (SIZE + SPACING) - 30)
  frame.empty:SetText('Nothing recorded yet.\nOpen your bank once and it will be remembered.')

  tinsert(UISpecialFrames, 'ForeverBankFrame')
  frame:Hide()
end

local function toggle()
  buildFrame()
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

---------------------------------------------------------------------------
-- Minimap button
---------------------------------------------------------------------------

local function placeMinimapButton()
  if not minimapButton then return end
  local a = math.rad(db.minimapAngle or 200)
  local r = (Minimap:GetWidth() / 2) + 5
  minimapButton:ClearAllPoints()
  minimapButton:SetPoint('CENTER', Minimap, 'CENTER', math.cos(a) * r, math.sin(a) * r)
end

local function buildMinimapButton()
  if minimapButton or not Minimap then return end
  local b = CreateFrame('Button', 'ForeverBankMinimapButton', Minimap)
  b:SetSize(31, 31)
  b:SetFrameStrata('MEDIUM')
  b:SetFrameLevel(8)
  b:RegisterForClicks('LeftButtonUp', 'RightButtonUp')
  b:RegisterForDrag('LeftButton')
  b:SetHighlightTexture('Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight')

  local bg = b:CreateTexture(nil, 'BACKGROUND')
  bg:SetSize(20, 20)
  bg:SetPoint('TOPLEFT', 7, -5)
  bg:SetTexture('Interface\\Minimap\\UI-Minimap-Background')

  local icon = b:CreateTexture(nil, 'ARTWORK')
  icon:SetSize(18, 18)
  icon:SetPoint('TOPLEFT', 7, -6)
  icon:SetTexture('Interface\\Icons\\INV_Misc_Bag_07')
  icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

  local ring = b:CreateTexture(nil, 'OVERLAY')
  ring:SetSize(53, 53)
  ring:SetPoint('TOPLEFT')
  ring:SetTexture('Interface\\Minimap\\MiniMap-TrackingBorder')

  b:SetScript('OnClick', toggle)
  b:SetScript('OnDragStart', function(self)
    self:SetScript('OnUpdate', function()
      local mx, my = Minimap:GetCenter()
      local cx, cy = GetCursorPosition()
      local s = Minimap:GetEffectiveScale()
      db.minimapAngle = math.deg(math.atan2(cy / s - my, cx / s - mx))
      placeMinimapButton()
    end)
  end)
  b:SetScript('OnDragStop', function(self) self:SetScript('OnUpdate', nil) end)
  b:SetScript('OnEnter', function(self)
    GameTooltip:SetOwner(self, 'ANCHOR_LEFT')
    GameTooltip:AddLine('Forever Bank')
    GameTooltip:AddLine('Click to show your bank.', 1, 1, 1)
    GameTooltip:AddLine('Drag to move this button.', 1, 1, 1)
    GameTooltip:Show()
  end)
  b:SetScript('OnLeave', function() GameTooltip:Hide() end)

  minimapButton = b
  placeMinimapButton()
  b:SetShown(db.showMinimap ~= false)
end

---------------------------------------------------------------------------
-- Slash command
---------------------------------------------------------------------------

local function slash(msg)
  msg = (msg or ''):lower()
  local cmd, arg = msg:match('^(%S*)%s*(.-)$')
  if cmd == '' then
    toggle()
  elseif cmd == 'cols' or cmd == 'columns' then
    local n = tonumber(arg)
    if n then
      db.columns = math.max(4, math.min(24, math.floor(n)))
      buildFrame() refresh()
      say('columns set to ' .. db.columns)
    else
      say('usage: /fbank cols 4-24')
    end
  elseif cmd == 'scale' then
    local n = tonumber(arg)
    if n then
      db.scale = math.max(0.5, math.min(2, n))
      buildFrame() frame:SetScale(db.scale)
      say('scale set to ' .. db.scale)
    else
      say('usage: /fbank scale 0.5-2')
    end
  elseif cmd == 'minimap' then
    db.showMinimap = not (db.showMinimap ~= false)
    if minimapButton then minimapButton:SetShown(db.showMinimap) end
    say('minimap button ' .. (db.showMinimap and 'shown' or 'hidden'))
  elseif cmd == 'debug' then
    local ids = {}
    for _, bag in ipairs(bankBags()) do ids[#ids + 1] = bag .. '=' .. numSlots(bag) end
    say('v' .. VERSION .. '  bank open: ' .. tostring(bankOpen))
    say('containers (id=slots): ' .. table.concat(ids, ' '))
    say('last scan: ' .. lastScanInfo)
    say('saved snapshot: ' .. (snap and (snap.filled .. ' items, ' .. ago(snap.time)) or 'none')
      .. '  loaded from disk: ' .. tostring(FOREVERBANK_LOADED_FROM_DISK))
  else
    say('/fbank  show or hide  |  cols N  |  scale N  |  minimap  |  debug')
  end
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------

local function adoptSaved()
  -- Settings: account table, or the per-character one if that is all we got.
  local hadAccount = type(ForeverBankDB) == 'table'
  local hadChar = type(ForeverBankCharDB) == 'table'
  FOREVERBANK_LOADED_FROM_DISK = (hadAccount and 'account' or '') .. (hadChar and ' char' or '')
  if FOREVERBANK_LOADED_FROM_DISK == '' then FOREVERBANK_LOADED_FROM_DISK = 'no' end
  if not hadAccount then ForeverBankDB = {} end
  if not hadChar then ForeverBankCharDB = {} end
  db = ForeverBankDB
  for k, v in pairs(defaults) do
    if db[k] == nil then db[k] = (type(v) == 'table') and {} or v end
  end
  charKey = (UnitName('player') or '?') .. '-' .. (GetRealmName and GetRealmName() or '?')
  local a, c = db.chars[charKey], ForeverBankCharDB.snap
  if type(a) == 'table' and type(c) == 'table' then
    snap = ((c.time or 0) > (a.time or 0)) and c or a
  else
    snap = (type(a) == 'table' and a) or (type(c) == 'table' and c) or nil
  end
end

local ev = CreateFrame('Frame')
local function reg(name) pcall(ev.RegisterEvent, ev, name) end
reg('PLAYER_LOGIN')
reg('BANKFRAME_OPENED')
reg('BANKFRAME_CLOSED')
reg('BAG_UPDATE')
reg('BAG_UPDATE_DELAYED')
reg('PLAYERBANKSLOTS_CHANGED')
reg('PLAYERBANKBAGSLOTS_CHANGED')
reg('PLAYER_MONEY')
reg('PLAYER_INTERACTION_MANAGER_FRAME_SHOW')
reg('PLAYER_INTERACTION_MANAGER_FRAME_HIDE')

local function isBankInteraction(kind)
  local T = Enum and Enum.PlayerInteractionType
  return T and kind ~= nil and (kind == T.Banker or kind == T.CharacterBanker)
end

ev:SetScript('OnEvent', function(_, event, arg1)
  if event == 'PLAYER_LOGIN' then
    adoptSaved()
    buildMinimapButton()
    SLASH_FOREVERBANK1 = '/fbank'
    SLASH_FOREVERBANK2 = '/foreverbank'
    SlashCmdList.FOREVERBANK = slash
    return
  end
  if not db then return end
  if event == 'BANKFRAME_OPENED' or (event == 'PLAYER_INTERACTION_MANAGER_FRAME_SHOW' and isBankInteraction(arg1)) then
    bankOpen = true
    queueScan()
  elseif event == 'BANKFRAME_CLOSED' or (event == 'PLAYER_INTERACTION_MANAGER_FRAME_HIDE' and isBankInteraction(arg1)) then
    -- no scan here: once the bank closes its slots read as empty
    bankOpen = false
    if frame and frame:IsShown() then refresh() end
  elseif event == 'PLAYER_MONEY' then
    if frame and frame:IsShown() then refresh() end
  elseif bankOpen then
    queueScan()
  end
end)
